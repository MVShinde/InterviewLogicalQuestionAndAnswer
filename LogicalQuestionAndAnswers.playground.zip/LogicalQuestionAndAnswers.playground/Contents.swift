/*Each day a plant is growing by upSpeed meters. Each night that plant's height decreases by downSpeed meters due to the lack of sun heat. Initially, plant is 0 meters tall. We plant the seed at the beginning of a day. We want to know when the height of the plant will reach a certain level.

Example
For upSpeed = 100, downSpeed = 10 and desiredHeight = 910, the output should be 10.

For upSpeed = 10, downSpeed = 9 and desiredHeight = 4, the output should be 1.
Because the plant reach to the desired height at day 1(10 meters).
*/


import UIKit

var str = ""

func calculateDays(upSpeed : Int, downSpeed : Int, desiredHeight : Int) -> Int {
    var height = 0
    var days = 0
    
    while height <= desiredHeight {
        height += upSpeed
        days += 1
        if height >= desiredHeight {
            return days
        }
        height -= downSpeed
    }
    return days
}

//Julie is x years older than her brother, and she is also y times as old as him.


func calculateAge(x: Int, y: Float) -> Int {
    return Int((Float(x)*y)/(y-1))
}
 
calculateAge(x: -15, y: 0.25)


func isLeapYear(year : Int) -> Bool {
    return (year % 100 != 0 && year % 4 == 0 ) || (year % 400 == 0)
}

isLeapYear(year: 2021)
